package main;

import database.DatabaseOperations;
import ui.UserInterface;

public class PersonalFinanceAdvisor12 {
    public static void main(String[] args) {
        DatabaseOperations db = new DatabaseOperations();
        UserInterface ui = new UserInterface(db);
        ui.startApplication();
    }
}