package ui;

import java.util.List;
import java.util.Scanner;
import java.util.Stack;
import database.DatabaseOperations;
import model.*;
import java.time.LocalDate;

public class UserInterface {
    Scanner sc = new Scanner(System.in);
    DatabaseOperations db;
    User currentUser = null;

    public UserInterface(DatabaseOperations db) {
        this.db = db;
    }

    public void startApplication() {
        while (true) {
            System.out.println("\n=== PERSONAL FINANCE ADVISOR ===");
            System.out.println("1. Admin Panel");
            System.out.println("2. User Panel");
            System.out.println("3. Exit");
            System.out.print("Select option: ");
            int input = sc.nextInt();

            switch (input) {
                case 1:
                    admin();
                    break;
                case 2:
                    user();
                    break;
                case 3:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please enter 1, 2 or 3.");
            }
        }
    }

    void admin() {
        while (true) {
            System.out.println("\n=== ADMIN ACCESS ===");
            System.out.println("1. Register Admin");
            System.out.println("2. Login as Admin");
            System.out.println("3. Back to Main Menu");
            System.out.print("Select option: ");
            int input = sc.nextInt();
            sc.nextLine();


            switch (input) {
                case 1:
                    registerAdmin();
                    break;
                case 2:
                    adminLogin();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    void registerAdmin() {
        User admin = new User();
        System.out.println("\n=== ADMIN REGISTRATION ===");
        while (true) {
            System.out.print("Username: ");
            admin.username = sc.nextLine().trim();

            if (admin.username.isEmpty()) {
                System.out.println(" Username cannot be empty!");
            } else {
                break;
            }
        }
        while (true) {
            System.out.print("Password (min 8 characters): ");
            admin.password = sc.nextLine();
            if (admin.password.length() < 8) {
                System.out.println(" Password must be at least 8 characters long!");
            } else {
                break;
            }
        }
        while (true) {
            System.out.print("Email: ");
            admin.email = sc.nextLine().trim();
            if (!admin.email.contains("@")) {
                System.out.println(" Invalid email! It must contain '@'.");
            } else {
                break;
            }
        }
        System.out.print("Full Name: ");
        admin.fullName = sc.nextLine().trim();
        admin.isAdmin = true;

        try {
            boolean success = db.registerAdmin(admin);
            if (success) {
                System.out.println(" Admin registered successfully!");
                adminLogin();
            } else {
                System.out.println(" Admin registration failed.");
            }
        } catch (Exception e) {
            System.out.println(" Unexpected error during admin registration.");
            e.printStackTrace();
        }
    }

    void adminLogin() {
        System.out.println("\n=== ADMIN LOGIN ===");

        System.out.print("Username: ");
        String username = sc.nextLine();
        System.out.print("Password: ");
        String password = sc.nextLine();

        currentUser = db.login(username, password);
        if (currentUser != null && currentUser.isAdmin) {
            adminMenu();
        } else {
            System.out.println("Invalid admin credentials.");
        }
    }

    void adminMenu() {
        while (currentUser != null) {
            System.out.println("\n=== ADMIN PANEL ===");
            System.out.println("1. View all users");
            System.out.println("2. Delete user");
            System.out.println("3. View all advice");
            System.out.println("4. Find Maximum Income ");
            System.out.println("5. Search Username ");
            System.out.println("6. Logout");

            System.out.print("Select option: ");
            int input = sc.nextInt();
            sc.nextLine(); // Consume newline left-over

            switch (input) {
                case 1:
                    viewAllUsers();
                    break;
                case 2:
                    deleteUser();
                    break;
                case 3:
                    viewAllAdvice();
                    break;
                case 4:
                    findMaximumIncomeUsingStack();
                    break;
                case 5:
                    searchUsernameInBST();
                    break;
                case 6:
                    currentUser = null;
                    System.out.println("Logged out.");
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    void viewAllAdvice() {
        List<User> allUsers = db.getAllUsers();
        if (allUsers.isEmpty()) {
            System.out.println("\nNo users found in the system to provide advice for.");
            return;
        }

        System.out.println("\n=== ALL USERS' PERSONALIZED ADVICE ===");
        for (User user : allUsers) {
            System.out.println("\n--- Advice for User: " + user.username + " ---");
            // Temporarily set the current user to display advice for them
            User originalCurrentUser = this.currentUser; // Store current user
            this.currentUser = user; // Set new current user
            viewPersonalizedAdvice(); // Call the existing method to display advice
            this.currentUser = originalCurrentUser; // Restore original current user
        }
    }

    void viewAllUsers() {
        List<User> users = db.getAllUsers();
        System.out.printf("+----+------------+-----------------------+--------------------+-------+\n");
        System.out.printf("| ID | Username   | Email                 | Full Name          | Admin |\n");
        System.out.printf("+----+------------+-----------------------+--------------------+-------+\n");
        for (User user : users) {
            System.out.printf("| %-2d | %-10s | %-21s | %-18s | %-5s |\n",
                    user.id,
                    user.username,
                    user.email,
                    user.fullName,
                    user.isAdmin ? "Yes" : "No");
        }
        System.out.printf("+----+------------+-----------------------+--------------------+-------+\n");
    }

    void deleteUser() {
        System.out.print("Enter user ID to delete: ");
        try {
            int userId = Integer.parseInt(sc.nextLine());
            boolean deleted = db.deleteUser(userId);
            if (deleted) {
                System.out.println("User deleted successfully.");
            } else {
                System.out.println("User not found or delete failed.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Enter a numeric user ID.");
        }
    }

    public void registerUser() {
        User user = new User();
        System.out.println("\n=== USER REGISTRATION ===");

        while (true) {
            System.out.print("Username: ");
            user.username = sc.nextLine().trim();
            if (user.username.isEmpty()) {
                System.out.println(" Username cannot be empty!");
            } else {
                break;
            }
        }

        while (true) {
            System.out.print("Password (min 8 characters): ");
            user.password = sc.nextLine().trim();
            if (user.password.length() < 8) {
                System.out.println(" Password must be at least 8 characters long!");
            } else {
                break;
            }
        }

        while (true) {
            System.out.print("Email: ");
            user.email = sc.nextLine().trim();
            if (!user.email.contains("@")) {
                System.out.println(" Invalid email! It must contain '@'.");
            } else {
                break;
            }
        }

        System.out.print("Full Name: ");
        user.fullName = sc.nextLine().trim();
        user.isAdmin = false;

        try {
            boolean success = db.registerUser(user);
            if (success) {
                System.out.println(" User registered successfully!");
                userLogin();
            } else {
                System.out.println(" User registration failed due to unknown reason.");
            }
        } catch (Exception e) {
            System.out.println(" An unexpected error occurred during registration.");
            e.printStackTrace();
            user();
        }
    }

    public void userLogin() {
        System.out.println("\n=== USER LOGIN ===");

        String username, password;
        while (true) {
            System.out.print("Username: ");
            username = sc.nextLine().trim();
            if (username.isEmpty()) {
                System.out.println("Username cannot be empty!");
                continue;
            }
            break;
        }

        while (true) {
            System.out.print("Password: ");
            password = sc.nextLine();
            if (password.length() < 8) {
                System.out.println("Password must be at least 8 characters long!");
                continue;
            }
            break;
        }

        // Captcha
        String captcha = generateCaptcha(5);
        System.out.print("Enter captcha [" + captcha + "]: ");
        String userCaptcha = sc.nextLine();
        if (!captcha.equals(userCaptcha)) {
            System.out.println("Incorrect captcha. Please try again.");
            user();
            return;
        }

        currentUser = db.login(username, password);
        if (currentUser != null && !currentUser.isAdmin) {
            userMenu();
        } else {
            System.out.println("Invalid user input!");
            user();
        }
    }

    String generateCaptcha(int length) {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        String captcha = "";
        for (int i = 0; i < length; i++) {
            int idx = (int) (Math.random() * chars.length());
            captcha += chars.charAt(idx);
        }
        return captcha;
    }

    public void user() {
        while (true) {
            System.out.println("\n=== USER ACCESS ===");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Back to Main Menu");
            System.out.print("Select option: ");
            int input = sc.nextInt();
            switch (input) {
                case 1:
                    registerUser();
                    return;
                case 2:
                    userLogin();
                    return;
                case 3:
                    return;
                default:
                    System.out.println("Invalid option. Please enter 1, 2, or 3.");
            }
        }
    }

    public void userMenu() {
        while (currentUser != null) {
            System.out.println("\n=== USER PANEL ===");
            System.out.println("1. Add income");
            System.out.println("2. Add expense");
            System.out.println("3. Add investment");
            System.out.println("4. View history & report");
            System.out.println("5. View my advice");
            System.out.println("6. Logout");
            System.out.print("Select option: ");
            int choice = sc.nextInt();
            sc.nextLine(); // Consume the leftover newline character

            switch (choice) {
                case 1:
                    addIncome();
                    break;
                case 2:
                    addExpense();
                    break;
                case 3:
                    addInvestment();
                    break;
                case 4:
                    viewHistoryAndReport();
                    break;
                case 5:
                    viewPersonalizedAdvice();
                    break;
                case 6:
                    currentUser = null;
                    System.out.println("Logged out.");
                    return;
                default:
                    System.out.println("Invalid option!");
            }
        }
    }

    void addIncome() {
        Income income = new Income();
        income.userId = currentUser.id;

        System.out.print("\nAmount: ");
        try {
            income.amount = Double.parseDouble(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid amount! Using 0.");
            income.amount = 0;
        }

        System.out.print("Source: ");
        income.source = sc.nextLine();

        System.out.print("Date (YYYY-MM-DD): ");
        try {
            String dateString = sc.nextLine();
            if (isValidDate(dateString)) {
                income.incomeDate = dateString;
            } else {
                System.out.println("Invalid date or date is beyond 2025-08-23! Using today's date.");
                income.incomeDate = getCurrentDate();
            }
        } catch (Exception e) {
            System.out.println("Invalid date format! Using today's date.");
            income.incomeDate = getCurrentDate();
        }

        if (db.addIncome(income)) {
            System.out.println("Income added successfully!");
        } else {
            System.out.println("Failed to add income!");
        }
    }

    void addExpense() {
        Expense expense = new Expense();
        expense.userId = currentUser.id;

        System.out.print("\nAmount: ");
        try {
            expense.amount = Double.parseDouble(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid amount! Using 0.");
            expense.amount = 0;
        }

        System.out.print("Category (Food, Transport, Entertainment, etc.): ");
        expense.category = sc.nextLine();

        System.out.print("Description: ");
        expense.description = sc.nextLine();

        System.out.print("Date (YYYY-MM-DD): ");
        try {
            String dateString = sc.nextLine();
            if (isValidDate(dateString)) {
                expense.expenseDate = dateString;
            } else {
                System.out.println("Invalid date or date is beyond 2025-08-23! Using today's date.");
                expense.expenseDate = getCurrentDate();
            }
        } catch (Exception e) {
            System.out.println("Invalid date format! Using today's date.");
            expense.expenseDate = getCurrentDate();
        }

        if (db.addExpense(expense)) {
            System.out.println("Expense added successfully!");
        } else {
            System.out.println("Failed to add expense!");
        }
    }

    void addInvestment() {
        System.out.println("\n1. Add new investment");
        System.out.println("2. Add investment return");
        System.out.println("3. Update investment current value");
        System.out.print("Select option: ");
        String choice = sc.nextLine();

        if (choice.equals("1")) {
            Investment investment = new Investment();
            investment.userId = currentUser.id;
            System.out.print("\nInvestment name: ");
            investment.name = sc.nextLine();
            System.out.print("Type (Mutual Fund, Stocks, Gold, FD, etc.): ");
            investment.type = sc.nextLine();

            System.out.print("Amount: ");
            try {
                investment.amount = Double.parseDouble(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid amount! Using 0.");
                investment.amount = 0;
            }

            System.out.print("Current Value (leave blank if unknown): ");
            String currentValueStr = sc.nextLine();
            if (!currentValueStr.isEmpty()) {
                try {
                    investment.currentValue = Double.parseDouble(currentValueStr);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid value! Using null.");
                    investment.currentValue = null;
                }
            }

            System.out.print("Return rate (%): ");
            try {
                investment.returnRate = Double.parseDouble(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid percent! Using 0.");
                investment.returnRate = 0;
            }

            System.out.print("Start date (YYYY-MM-DD): ");
            try {
                String dateString = sc.nextLine();
                if (isValidDate(dateString)) {
                    investment.startDate = dateString;
                } else {
                    System.out.println("Invalid date or date is beyond 2025-08-23! Using today's date.");
                    investment.startDate = getCurrentDate();
                }
            } catch (Exception e) {
                System.out.println("Invalid date format! Using today's date.");
                investment.startDate = getCurrentDate();
            }

            System.out.print("End date (YYYY-MM-DD, leave blank if ongoing): ");
            String endDateStr = sc.nextLine();
            if (!endDateStr.isEmpty()) {
                try {
                    // No validation for end date as per requirement
                    investment.endDate = endDateStr;
                } catch (Exception e) {
                    System.out.println("Invalid date! Setting to null.");
                    investment.endDate = null;
                }
            } else {
                investment.endDate = null;
            }

            if (db.addInvestment(investment)) {
                System.out.println("Investment added successfully!");
            } else {
                System.out.println("Failed to add investment!");
            }
        } else if (choice.equals("2")) {
            InvestmentReturn investmentReturn = new InvestmentReturn();

            System.out.print("\nInvestment ID: ");
            try {
                investmentReturn.investmentId = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid ID! Using 0.");
                investmentReturn.investmentId = 0;
            }

            System.out.print("Return amount: ");
            try {
                investmentReturn.amount = Double.parseDouble(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid amount! Using 0.");
                investmentReturn.amount = 0;
            }

            System.out.print("Date (YYYY-MM-DD): ");
            try {
                // No validation for return date as per requirement
                investmentReturn.returnDate = sc.nextLine();
            } catch (Exception e) {
                System.out.println("Invalid date! Using today's date.");
                investmentReturn.returnDate = getCurrentDate();
            }

            if (db.addInvestmentReturn(investmentReturn)) {
                System.out.println("Investment return added successfully!");
            } else {
                System.out.println("Failed to add investment return!");
            }
        } else if (choice.equals("3")) {
            System.out.print("\nInvestment ID to update: ");
            int investmentId;
            try {
                investmentId = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid ID! Operation cancelled.");
                return;
            }

            System.out.print("New current value: ");
            double currentValue;
            try {
                currentValue = Double.parseDouble(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid value! Operation cancelled.");
                return;
            }

            if (db.updateInvestmentCurrentValue(investmentId, currentValue)) {
                System.out.println("Investment current value updated successfully!");
            } else {
                System.out.println("Failed to update investment current value!");
            }
        } else {
            System.out.println("Invalid option.");
        }
    }

    void viewPersonalizedAdvice() {
        List<Income> incomes = db.getUserIncome(currentUser.id);
        List<Expense> expenses = db.getUserExpenses(currentUser.id);
        List<Investment> investments = db.getUserInvestments(currentUser.id);

        // Calculate totals in simple way
        double incomeTotal = 0;
        for (Income i : incomes) incomeTotal += i.amount;

        double expenseTotal = 0;
        for (Expense e : expenses) expenseTotal += e.amount;

        double savings = incomeTotal - expenseTotal;

        double investedTotal = 0;
        for (Investment i : investments) investedTotal += i.amount;

        double investmentPercentage = 0;
        if (savings > 0) {
            investmentPercentage = (investedTotal / savings) * 100;
        }

        System.out.println("\n=== PERSONALIZED INVESTMENT ADVICE ===");
        System.out.printf("Your current investment percentage:" + investmentPercentage + " of your savings\n");

        if (investmentPercentage < 20) {
            System.out.println("\n Recommendation: You should invest more! Ideal is 30-50% of savings");
            System.out.println("- Invest ₹2,000/month in a Large-Cap Index Fund");
            System.out.println("- Allocate 5-10% of your portfolio (₹500-₹1,000) in Digital Gold");
            System.out.println("- Put ₹1,500-₹2,000 into a short-term FD for guaranteed returns");
        } else if (investmentPercentage < 40) {
            System.out.println("\n Recommendation: Good start! Consider diversifying more");
            System.out.println("- Increase SIP in Index Funds by 10% every year");
            System.out.println("- Add 5% allocation to International Funds");
            System.out.println("- Consider ₹3,000/month in Hybrid Funds for balanced growth");
        } else {
            System.out.println("\n Recommendation: Well done! Maintain your investment discipline");
            System.out.println("- Rebalance portfolio annually to maintain asset allocation");
            System.out.println("- Consider tax-saving instruments like ELSS if not already invested");
            System.out.println("- Keep 10-15% in liquid funds for emergencies");
        }

        System.out.println("\nGeneral Investment Principles:");
        System.out.println("- Invest minimum 30% of your monthly savings");
        System.out.println("- Diversify across equity (50%), debt (30%), and gold (20%)");
        System.out.println("- Review portfolio every 6 months");
        System.out.println("- Increase SIP amounts with salary hikes");
    }

    void viewHistoryAndReport() {
        System.out.println("\n=== FINANCIAL HISTORY & REPORT ===");
        System.out.println("Generating your personalized financial report...\n");

        List<Income> incomes = db.getUserIncome(currentUser.id);
        List<Expense> expenses = db.getUserExpenses(currentUser.id);
        List<Investment> investments = db.getUserInvestments(currentUser.id);

        // Calculate totals in simple way
        double incomeTotal = 0;
        for (Income i : incomes) incomeTotal += i.amount;

        double expenseTotal = 0;
        for (Expense e : expenses) expenseTotal += e.amount;

        double investedTotal = 0;
        for (Investment i : investments) investedTotal += i.amount;

        double currentInvestmentValue = 0;
        for (Investment i : investments) {
            if (i.currentValue != null) {
                currentInvestmentValue += i.currentValue;
            }
        }

        // Print report
        System.out.println("+---------------------------------------------------+");
        System.out.println("|                FINANCIAL SNAPSHOT                |");
        System.out.println("+---------------------------------------------------+");
        System.out.printf("| %-30s ₹%-12.2f |\n", "Total Income:", incomeTotal);
        System.out.printf("| %-30s ₹%-12.2f |\n", "Total Expenses:", expenseTotal);
        System.out.printf("| %-30s ₹%-12.2f |\n", "Net Savings:", incomeTotal - expenseTotal);
        System.out.printf("| %-30s ₹%-12.2f |\n", "Total Invested:", investedTotal);
        if (currentInvestmentValue > 0) {
            System.out.printf("| %-30s ₹%-12.2f |\n", "Current Investment Value:", currentInvestmentValue);
            double profitLoss = currentInvestmentValue - investedTotal;
            System.out.printf("| %-30s ₹%-12.2f (%s) |\n",
                    "Profit/Loss:",
                    Math.abs(profitLoss),
                    profitLoss >= 0 ? "Profit" : "Loss");
        }
        System.out.println("+---------------------------------------------------+");

        // Income details
        System.out.println("\n=== INCOME DETAILS ===");
        if (incomes.isEmpty()) {
            System.out.println("No income records found.");
        } else {
            System.out.printf("%-12s %-20s %-10s %s\n", "Date", "Source", "Amount", "Percentage");
            System.out.println("--------------------------------------------------");
            for (Income income : incomes) {
                double percentage = (income.amount / incomeTotal) * 100;
                System.out.printf("%-12s %-20s ₹%-9.2f %.1f%%\n",
                        income.incomeDate,
                        income.source,
                        income.amount,
                        percentage);
            }
        }

        // Expense details
        System.out.println("\n=== EXPENSE DETAILS ===");
        if (expenses.isEmpty()) {
            System.out.println("No expense records found.");
        } else {
            System.out.printf("%-12s %-15s %-25s %-10s %s\n",
                    "Date", "Category", "Description", "Amount", "Percentage");
            System.out.println("------------------------------------------------------------------");
            for (Expense expense : expenses) {
                double percentage = (expense.amount / expenseTotal) * 100;
                System.out.printf("%-12s %-15s %-25s ₹%-9.2f %.1f%%\n",
                        expense.expenseDate,
                        expense.category,
                        expense.description,
                        expense.amount,
                        percentage);
            }
        }

        // Investment details
        System.out.println("\n=== INVESTMENT DETAILS ===");
        if (investments.isEmpty()) {
            System.out.println("No investment records found.");
        } else {
            System.out.printf("%-20s %-15s %-10s %-10s %-6s %-12s %s\n",
                    "Name", "Type", "Invested", "Current", "Return", "Start Date", "End Date");
            System.out.println("--------------------------------------------------------------------------------");
            for (Investment investment : investments) {
                System.out.printf("%-20s %-15s ₹%-9.2f %-10s %-5.2f%% %-12s %s\n",
                        investment.name,
                        investment.type,
                        investment.amount,
                        investment.currentValue != null ? String.format("₹%.2f", investment.currentValue) : "N/A",
                        investment.returnRate,
                        investment.startDate,
                        investment.endDate != null ? investment.endDate : "Ongoing");
            }
        }

        // Financial analysis
        System.out.println("\n=== FINANCIAL HEALTH ANALYSIS ===");
        double savingsRate = ((incomeTotal - expenseTotal) / incomeTotal) * 100;
        if (incomeTotal > 0) {
            System.out.printf("Savings Rate: %.1f%% of your income\n", savingsRate);

            if (savingsRate > 20) {
                System.out.println(" Excellent! You're saving more than 20% of your income.");
            } else if (savingsRate > 10) {
                System.out.println(" Good! Consider increasing savings to 20% for better financial security.");
            } else {
                System.out.println(" Warning! Your savings rate is low. Try to reduce expenses ");
            }
        }

        if (investedTotal > 0) {
            double investmentRatio = (investedTotal / (incomeTotal - expenseTotal)) * 100;
            System.out.printf("\nInvestment Ratio: %.1f%% of your savings are invested\n", investmentRatio);

            if (investmentRatio > 50) {
                System.out.println(" Great! You're investing a significant portion of your savings.");
            } else if (investmentRatio > 20) {
                System.out.println(" Good start! Consider increasing investments for better returns.");
            } else {
                System.out.println("ℹ You might want to invest more of your savings for long-term growth.");
            }
        }

        System.out.println("\nReport generated on: " + java.time.LocalDate.now());
    }

    void findMaximumIncomeUsingStack() {
        List<Income> incomes = db.getAllIncomes();
        if (incomes.isEmpty()) {
            System.out.println("No income records found to find maximum.");
            return;
        }

        Stack<Income> incomeStack = new Stack<>();
        for (Income income : incomes) {
            incomeStack.push(income);
        }

        Income maxIncome = null;
        double maxAmount = -1;

        while (!incomeStack.isEmpty()) {
            Income current = incomeStack.pop();
            if (current.amount > maxAmount) {
                maxAmount = current.amount;
                maxIncome = current;
            }
        }

        if (maxIncome != null) {
            User userWithMaxIncome = db.getUserById(maxIncome.userId);
            System.out.println("\n=== USER WITH MAXIMUM INCOME ===");
            if (userWithMaxIncome != null) {
                System.out.printf("+----+------------+-----------------------+--------------------+\n");
                System.out.printf("| ID | Username   | Email                 | Full Name          |\n");
                System.out.printf("+----+------------+-----------------------+--------------------+\n");
                System.out.printf("| %-2d | %-10s | %-21s | %-18s |\n",
                        userWithMaxIncome.id,
                        userWithMaxIncome.username,
                        userWithMaxIncome.email,
                        userWithMaxIncome.fullName);
                System.out.printf("+----+------------+-----------------------+--------------------+\n");
                System.out.printf("Maximum Income: ₹%.2f (Source: %s, Date: %s)\n",
                        maxIncome.amount, maxIncome.source, maxIncome.incomeDate);
            } else {
                System.out.println("User details not found for the maximum income record.");
            }
        } else {
            System.out.println("No income records found.");
        }
    }

    void searchUsernameInBST() {
        System.out.print("Enter username to search: ");
        String usernameToSearch = sc.nextLine();
        List<String> usernames = db.getAllUsernames();
        BinarySearchTree bst = new BinarySearchTree();
        for (String username : usernames) {
            bst.insert(username);
        }

        if (bst.search(usernameToSearch)) {
            System.out.println("Username '" + usernameToSearch + "' found in the BST.");
            User foundUser = db.getUserByUsername(usernameToSearch);
            if (foundUser != null) {
                System.out.println("\n--- User Details ---");
                System.out.printf("+----+------------+-----------------------+--------------------+-------+\n");
                System.out.printf("| ID | Username   | Email                 | Full Name          | Admin |\n");
                System.out.printf("+----+------------+-----------------------+--------------------+-------+\n");
                System.out.printf("| %-2d | %-10s | %-21s | %-18s | %-5s |\n",
                        foundUser.id,
                        foundUser.username,
                        foundUser.email,
                        foundUser.fullName,
                        foundUser.isAdmin ? "Yes" : "No");
                System.out.printf("+----+------------+-----------------------+--------------------+-------+\n");
            } else {
                System.out.println("User details could not be retrieved.");
            }
        } else {
            System.out.println("Username '" + usernameToSearch + "' not found in the BST.");
        }
    }

    private boolean isValidDate(String dateStr) {
        if (dateStr == null || !dateStr.matches("\\d{4}-\\d{2}-\\d{2}")) {
            return false;
        }
        String[] parts = dateStr.split("-");
        int year = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]);
        int day = Integer.parseInt(parts[2]);

        // Check against 2025-08-23
        if (year > 2025) return false;
        if (year == 2025 && month > 8) return false;
        if (year == 2025 && month == 8 && day > 23) return false;

        // Basic date validity check (e.g., month 1-12, day 1-31)
        if (month < 1 || month > 12) return false;
        if (day < 1 || day > 31) return false; // Simple check, more robust needed for real app

        return true;
    }

    private String getCurrentDate() {
        // For simplicity, returning a fixed date or current system date as string
        // In a real application, consider java.time.LocalDate for robust date handling
        return java.time.LocalDate.now().toString();
    }
}