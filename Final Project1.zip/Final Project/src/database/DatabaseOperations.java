package database;

import model.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;



public class DatabaseOperations {
    public String url = "jdbc:mysql://localhost:3306/het2";
    public String username = "root";
    public String password = "";


    Connection conn() throws SQLException {
        return DriverManager.getConnection(url, username,password);
    }

    public boolean registerUser(User user) throws Exception {

        String sql = "{call registerUser(?, ?, ?, ?, ?)}";
        try (Connection con = conn();
             CallableStatement pst = con.prepareCall(sql)) {
            pst.setString(1, user.username);
            pst.setString(2, user.password);
            pst.setString(3, user.email);
            pst.setString(4, user.fullName);
            pst.setBoolean(5, user.isAdmin);
            return pst.executeUpdate() > 0;
        } catch (SQLIntegrityConstraintViolationException e) {
            System.out.println("user name is already exist! please chose another");
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean registerAdmin(User admin) throws Exception {
        admin.isAdmin = true;
        return registerUser(admin);
    }

    public User login(String username, String password) {
        String sql = "{call login(?,?)}";
        try (Connection con = conn();
             CallableStatement pst = con.prepareCall(sql)) {
            pst.setString(1, username);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                User user = new User();
                user.id = rs.getInt("user_id");
                user.username = rs.getString("username");
                user.password = rs.getString("password");
                user.email = rs.getString("email");
                user.fullName = rs.getString("full_name");
                user.isAdmin = rs.getBoolean("is_admin");
                return user;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean addIncome(Income income) {
        String sql = "{call addIncome(?, ?, ?, ?)}";
        try (Connection con = conn();
             CallableStatement pst = con.prepareCall(sql)) {
            pst.setInt(1, income.userId);
            pst.setDouble(2, income.amount);
            pst.setString(3, income.source);
            pst.setString(4, income.incomeDate);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean addExpense(Expense expense) {
        String sql = "{call addExpense(?, ?, ?, ?, ?)}";
        try (Connection con = conn();
             CallableStatement pst = con.prepareCall(sql)) {
            pst.setInt(1, expense.userId);
            pst.setDouble(2, expense.amount);
            pst.setString(3, expense.category);
            pst.setString(4, expense.description);
            pst.setString(5, expense.expenseDate);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean addInvestment(Investment investment) {
        String sql = "INSERT INTO investments (user_id, name, type, amount, current_value, return_rate, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = conn();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, investment.userId);
            pst.setString(2, investment.name);
            pst.setString(3, investment.type);
            pst.setDouble(4, investment.amount);
            pst.setObject(5, investment.currentValue);
            pst.setDouble(6, investment.returnRate);
            pst.setString(7, investment.startDate);
            pst.setString(8, investment.endDate);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean addInvestmentReturn(InvestmentReturn investmentReturn) {
        String sql = "INSERT INTO investment_returns (investment_id, amount, return_date) VALUES (?, ?, ?)";
        try (Connection con = conn();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, investmentReturn.investmentId);
            pst.setDouble(2, investmentReturn.amount);
            pst.setString(3, investmentReturn.returnDate);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateInvestmentCurrentValue(int investmentId, double currentValue) {
        String sql = "UPDATE investments SET current_value = ? WHERE investment_id = ?";
        try (Connection con = conn();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setDouble(1, currentValue);
            pst.setInt(2, investmentId);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Income> getUserIncome(int userId) {
        List<Income> incomes = new ArrayList<>();

        String sql = "{call getUserIncome(?)}";
        try (Connection con = conn();
             CallableStatement pst = con.prepareCall(sql)) {
            pst.setInt(1, userId);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Income income = new Income();
                income.id = rs.getInt("income_id");
                income.userId = rs.getInt("user_id");
                income.amount = rs.getDouble("amount");
                income.source = rs.getString("source");
                income.incomeDate = rs.getString("income_date");
                incomes.add(income);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return incomes;
    }

    public List<Expense> getUserExpenses(int userId) {
        List<Expense> expenses = new ArrayList<>();
        String sql = "SELECT * FROM expenses WHERE user_id = ? ORDER BY expense_date DESC";
        try (Connection con = conn();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, userId);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Expense expense = new Expense();
                expense.id = rs.getInt("expense_id");
                expense.userId = rs.getInt("user_id");
                expense.amount = rs.getDouble("amount");
                expense.category = rs.getString("category");
                expense.description = rs.getString("description");
                expense.expenseDate = rs.getString("expense_date");
                expenses.add(expense);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return expenses;
    }

    public List<Investment> getUserInvestments(int userId) {
        List<Investment> investments = new ArrayList<>();
        String sql = "SELECT * FROM investments WHERE user_id = ?";
        try (Connection con = conn();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, userId);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Investment investment = new Investment();
                investment.id = rs.getInt("investment_id");
                investment.userId = rs.getInt("user_id");
                investment.name = rs.getString("name");
                investment.type = rs.getString("type");
                investment.amount = rs.getDouble("amount");
                investment.currentValue = rs.getDouble("current_value");
                if (rs.wasNull()) investment.currentValue = null;
                investment.returnRate = rs.getDouble("return_rate");
                investment.startDate = rs.getString("start_date");
                investment.endDate = rs.getString("end_date");
                investments.add(investment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return investments;
    }

    public boolean addUserAdvice(int userId, String advice) {
        String sql = "INSERT INTO user_advice (user_id, advice) VALUES (?, ?)";
        try (Connection con = conn();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, userId);
            pst.setString(2, advice);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<String> getUserAdvice(int userId) {
        List<String> adviceList = new ArrayList<>();
        String sql = "SELECT advice FROM user_advice WHERE user_id = ?";
        try (Connection con = conn();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, userId);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                adviceList.add(rs.getString("advice"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return adviceList;
    }

    public List<String> getAllAdvice() {
        List<String> adviceList = new ArrayList<>();
        String sql = "SELECT advice FROM investment_advice";
        try (Connection con = conn();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                adviceList.add(rs.getString("advice"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return adviceList;
    }

    public List<Income> getAllIncomes() {
        List<Income> incomes = new ArrayList<>();
        String sql = "SELECT income_id, user_id, amount, source, income_date FROM income";
        try (Connection con = conn();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Income income = new Income();
                income.id = rs.getInt("income_id");
                income.userId = rs.getInt("user_id");
                income.amount = rs.getDouble("amount");
                income.source = rs.getString("source");
                income.incomeDate = rs.getString("income_date");
                incomes.add(income);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return incomes;
    }

    public List<String> getAllUsernames() {
        List<String> usernames = new ArrayList<>();
        String sql = "SELECT username FROM users";
        try (Connection con = conn();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                usernames.add(rs.getString("username"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usernames;
    }

    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM users";
        try (Connection con = conn();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                User user = new User();
                user.id = rs.getInt("user_id");
                user.username = rs.getString("username");
                user.password = rs.getString("password");
                user.email = rs.getString("email");
                user.fullName = rs.getString("full_name");
                user.isAdmin = rs.getBoolean("is_admin");
                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }

    public boolean deleteUser(int userId) {
        String sql = "DELETE FROM users WHERE user_id = ?";
        try (Connection con = conn();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, userId);
            return pst.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<User> searchUsers(String keyword) {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM users WHERE username LIKE ? OR email LIKE ? OR full_name LIKE ?";
        try (Connection con = conn();
             PreparedStatement pst = con.prepareStatement(sql)) {
            String searchTerm = "%" + keyword + "%";
            pst.setString(1, searchTerm);
            pst.setString(2, searchTerm);
            pst.setString(3, searchTerm);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                User user = new User();
                user.id = rs.getInt("user_id");
                user.username = rs.getString("username");
                user.email = rs.getString("email");
                user.fullName = rs.getString("full_name");
                user.isAdmin = rs.getBoolean("is_admin");
                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }

    public User getUserById(int userId) {
        String sql = "SELECT * FROM users WHERE user_id = ?";
        try (Connection con = conn();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, userId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                User user = new User();
                user.id = rs.getInt("user_id");
                user.username = rs.getString("username");
                user.password = rs.getString("password");
                user.email = rs.getString("email");
                user.fullName = rs.getString("full_name");
                user.isAdmin = rs.getBoolean("is_admin");
                return user;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public User getUserByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username = ?";
        try (Connection con = conn();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, username);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                User user = new User();
                user.id = rs.getInt("user_id");
                user.username = rs.getString("username");
                user.password = rs.getString("password");
                user.email = rs.getString("email");
                user.fullName = rs.getString("full_name");
                user.isAdmin = rs.getBoolean("is_admin");
                return user;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}