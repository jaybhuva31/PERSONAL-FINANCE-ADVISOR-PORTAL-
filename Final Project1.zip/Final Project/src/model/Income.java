package model;

public class Income {
    public int id;
    public int userId;
    public double amount;
    public String source;
    public String incomeDate;
}