package model;

public class Expense {
    public int id;
    public int userId;
    public double amount;
    public String category;
    public String description;
    public String expenseDate;
}