package model;

public class InvestmentReturn {
    public int id;
    public int investmentId;
    public double amount;
    public String returnDate;
}