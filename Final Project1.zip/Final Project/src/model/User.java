package model;

public class User {
    public int id;
    public String username;
    public String password;
    public String email;
    public String fullName;
    public boolean isAdmin;
}