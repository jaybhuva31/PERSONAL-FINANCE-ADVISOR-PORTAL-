package model;

public class Investment {
    public int id;
    public int userId;
    public String name;
    public String type;
    public double amount;
    public Double currentValue;
    public double returnRate;
    public String startDate;
    public String endDate;
}