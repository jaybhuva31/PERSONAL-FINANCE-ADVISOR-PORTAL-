package model;

public class BSTNode {
    public String username;
    public BSTNode left;
    public BSTNode right;

    public BSTNode(String username) {
        this.username = username;
        this.left = null;
        this.right = null;
    }
}