package model;

public class BinarySearchTree {
    public BSTNode root;

    public BinarySearchTree() {
        root = null;
    }

    public void insert(String username) {
        root = insertRec(root, username);
    }

    private BSTNode insertRec(BSTNode root, String username) {
        if (root == null) {
            root = new BSTNode(username);
            return root;
        }

        if (username.compareTo(root.username) < 0) {
            root.left = insertRec(root.left, username);
        } else if (username.compareTo(root.username) > 0) {
            root.right = insertRec(root.right, username);
        }
        return root;
    }

    public boolean search(String username) {
        return searchRec(root, username);
    }

    private boolean searchRec(BSTNode root, String username) {
        if (root == null) {
            return false;
        }
        if (root.username.equals(username)) {
            return true;
        }
        if (username.compareTo(root.username) < 0) {
            return searchRec(root.left, username);
        } else {
            return searchRec(root.right, username);
        }
    }
}