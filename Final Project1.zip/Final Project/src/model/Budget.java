package model;

import java.sql.Date;

public class Budget {
    public int id;
    public int userId;
    public String category;
    public double amount;
    public Date startDate;
    public Date endDate;
}